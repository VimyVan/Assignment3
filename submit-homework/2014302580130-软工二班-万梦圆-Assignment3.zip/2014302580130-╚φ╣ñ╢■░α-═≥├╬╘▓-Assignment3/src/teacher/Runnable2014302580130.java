package teacher;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Runnable2014302580130 implements Runnable
{

	String[] teacherInfo=new String[5];
	String details;
	String URL;
	public Runnable2014302580130(String teacherUrl)
	{
		URL=teacherUrl;
		
	}
	@Override
	public void run()
	{
		// TODO Auto-generated method stub
		
		try 
		{
			Document doc_1;
			doc_1 = Jsoup.connect(URL).get();
			Elements links_1=doc_1.select("h3");
			for (Element link_1 : links_1) 
		    {
				teacherInfo[0]= link_1.text();
		    }
			Elements links_2=doc_1.select("div[class=details col-md-10 col-sm-9 col-xs-7]>p");
		    for (Element link_2 : links_2) 
		    {
		    	details=link_2.text();
			    Pattern p1=Pattern.compile("[\\w\\.\\-]+@([\\w\\-]+\\.)+[\\w\\-]+"); 
			    Matcher m1=p1.matcher(details); 
			    if(m1.find()) { 
			    	teacherInfo[4]=m1.group(0); 
			    	}
			    else{teacherInfo[4]=null;}

			    
			    Pattern p2=Pattern.compile("\\d{5,}"); 
			    Matcher m2=p2.matcher(details); 
			    if(m2.find()) {teacherInfo[3]=m2.group(0); }
			    else{teacherInfo[3]=null;}

			    
			    Pattern p3=Pattern.compile("��ʿ|˶ʿ"); 
			    Matcher m3=p3.matcher(details);
			    Pattern p4=Pattern.compile("����|������"); 
			    Matcher m4=p4.matcher(details);
			   if(m3.find()&&m4.find()) {teacherInfo[1]=m3.group(0)+m4.group(0); }
			    else{
			    	if(m3.find()){teacherInfo[1]=m3.group(0);}
			    	else{
			    		if(m4.find()){teacherInfo[1]=m4.group(0);}
			    		else{teacherInfo[1]=null;}
			    		}
			    	}

			  
			  ;
			   Pattern p5=Pattern.compile("[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
			   Matcher m5=p5.matcher(details);
			   Pattern p6=Pattern.compile("[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
			   Matcher m6=p6.matcher(details);
			   Pattern p7=Pattern.compile("[a-zA-Z]+[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
			   Matcher m7=p7.matcher(details);
			   Pattern p8=Pattern.compile("[\\u4e00-\\u9fa5]+��[a-zA-Z]+[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
			   Matcher m8=p8.matcher(details);
			   Pattern p9=Pattern.compile("[\\u4e00-\\u9fa5]+��[a-zA-Z]+[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
			   Matcher m9=p9.matcher(details);
			   Pattern p10=Pattern.compile("��Ϣ��ȫ"); 
			   Matcher m10=p10.matcher(details);
			   Pattern p11=Pattern.compile("���ܼ���"); 
			   Matcher m11=p11.matcher(details);
			   if(m5.find()) {teacherInfo[2]=m5.group(0); }
			    else{  if(m6.find()) {teacherInfo[2]=m6.group(0); }
			    else{ if(m7.find()) {teacherInfo[2]=m7.group(0); }
			    else{ if(m8.find()) {teacherInfo[2]=m8.group(0); }
			    else{ if(m9.find()) {teacherInfo[2]=m9.group(0); }
			    else{ if(m10.find()) {teacherInfo[2]=m10.group(0); }
			    else{ if(m11.find()) {teacherInfo[2]=m11.group(0); }
			    else{teacherInfo[2]=null;}}}}}}}
			   

			 }
		    Connection connect;
			try {
				connect = DriverManager.getConnection(  
				          "jdbc:mysql://localhost:3306/teacher","root","19960921");
				 Statement stmt = connect.createStatement();
			      String sql;
			      sql = "insert into teacher(name,introduction,researcharea,tel,email) "
		                		+ "values('"+teacherInfo[0]+"','"+teacherInfo[1]+"','"+teacherInfo[2]+"','"+teacherInfo[3]+"','"+teacherInfo[4]+"')";
			      stmt.executeUpdate(sql);
			Main2014302580130.latch.countDown();    		  
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
			     

		
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
	    
	    
	


