package teacher;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public  class Crawl2014302580130 {
	public  String[][] table = new String[11][5];
	public static String name;
	public static String details;
	public static StringBuffer introduction;
	public static StringBuffer researcharea;
	public static StringBuffer tel;
	public static StringBuffer email;
	public String[] teacherURL=new String[11];
	
	public  void Crawl(){
		try {
			Document doc = Jsoup.connect("http://staff.whu.edu.cn/?key=&title=0&showhomepage=0&college=%E8%AE%A1%E7%AE%97%E6%9C%BA%E5%AD%A6%E9%99%A2&cid=211&lang=cn").get();
			Elements links =doc.select("p>a");
			Elements links_1 =doc.select("strong");
			int n=0;
			for (Element link_1 : links_1) {
		    	table[n][0]= link_1.text();
		    	n++;

		    }
			int i=0;
			
				for (Element link : links) {
					
					//String teacherURL=link.attr("abs:href");
					teacherURL[i]=link.attr("abs:href");

				    Document doc_1=Jsoup.connect(teacherURL[i]).get();
				    
				    Elements links_2=doc_1.select("div[class=details col-md-10 col-sm-9 col-xs-7]>p");
				    for (Element link_2 : links_2) {
				    	details=link_2.text();
					    Pattern p1=Pattern.compile("[\\w\\.\\-]+@([\\w\\-]+\\.)+[\\w\\-]+"); 
					    Matcher m1=p1.matcher(details); 
					    if(m1.find()) { 
					    	table[i][4]=m1.group(0); 
					    	}
					    else{table[i][4]=null;}

					    
					    Pattern p2=Pattern.compile("\\d{5,}"); 
					    Matcher m2=p2.matcher(details); 
					    if(m2.find()) {table[i][3]=m2.group(0); }
					    else{table[i][3]=null;}

					    
					    Pattern p3=Pattern.compile("��ʿ|˶ʿ"); 
					    Matcher m3=p3.matcher(details);
					    Pattern p4=Pattern.compile("����|������"); 
					    Matcher m4=p4.matcher(details);
					   if(m3.find()&&m4.find()) {table[i][1]=m3.group(0)+m4.group(0); }
					    else{
					    	if(m3.find()){table[i][1]=m3.group(0);}
					    	else{
					    		if(m4.find()){table[i][1]=m4.group(0);}
					    		else{table[i][1]=null;}
					    		}
					    	}

					  
					  ;
					   Pattern p5=Pattern.compile("[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
					   Matcher m5=p5.matcher(details);
					   Pattern p6=Pattern.compile("[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
					   Matcher m6=p6.matcher(details);
					   Pattern p7=Pattern.compile("[a-zA-Z]+[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
					   Matcher m7=p7.matcher(details);
					   Pattern p8=Pattern.compile("[\\u4e00-\\u9fa5]+��[a-zA-Z]+[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
					   Matcher m8=p8.matcher(details);
					   Pattern p9=Pattern.compile("[\\u4e00-\\u9fa5]+��[a-zA-Z]+[\\u4e00-\\u9fa5]+��[\\u4e00-\\u9fa5]+"); 
					   Matcher m9=p9.matcher(details);
					   Pattern p10=Pattern.compile("��Ϣ��ȫ"); 
					   Matcher m10=p10.matcher(details);
					   Pattern p11=Pattern.compile("���ܼ���"); 
					   Matcher m11=p11.matcher(details);
					   if(m5.find()) {table[i][2]=m5.group(0); }
					    else{  if(m6.find()) {table[i][2]=m6.group(0); }
					    else{ if(m7.find()) {table[i][2]=m7.group(0); }
					    else{ if(m8.find()) {table[i][2]=m8.group(0); }
					    else{ if(m9.find()) {table[i][2]=m9.group(0); }
					    else{ if(m10.find()) {table[i][2]=m10.group(0); }
					    else{ if(m11.find()) {table[i][2]=m11.group(0); }
					    else{table[i][2]=null;}}}}}}}
					  					   
					   }
				    i++;
			}					
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
