package teacher;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class SQLoperation2014302580130 {
	Crawl2014302580130 Crawler=new Crawl2014302580130();
	
	public void Connect(){
		try {  
		      Class.forName("com.mysql.jdbc.Driver");    
		     System.out.println("Success loading Mysql Driver!");  
		    }  
		    catch (Exception e) {  
		      System.out.print("Error loading Mysql Driver!");  
		      e.printStackTrace();  
		    }  
	}

	public void CreateTable(){
		Connection connect;
		try {
			connect = DriverManager.getConnection(  
			          "jdbc:mysql://localhost:3306/teacher","root","19960921");
			System.out.println("Success connect Mysql server!");  
		      Statement stmt = connect.createStatement();
		      String sql;
	            sql = "create table teacher(name varchar(20),introduction varchar(20),researcharea varchar(50),tel varchar(20),email varchar(50),id int auto_increment primary key)";
	            int result = stmt.executeUpdate(sql);
	            if (result != -1) {
	                System.out.println("�������ݱ��ɹ�");}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		      
	                
	}
	//public void Insert(String name,String introduction,String researcharea,String tel,String email){
	public void Insert(){
		try {  
		      Connection connect = DriverManager.getConnection(  
		          "jdbc:mysql://localhost:3306/teacher","root","19960921");    
		      Statement stmt = connect.createStatement();
		      String sql;
		      for(int i=0;i<11;i++){
	               sql = "insert into teacher(name,introduction,researcharea,tel,email) "
	                		+ "values('"+Crawler.table[i][0]+"','"+Crawler.table[i][1]+"','"+Crawler.table[i][2]+"','"+Crawler.table[i][3]+"','"+Crawler.table[i][4]+"')";
	               stmt.executeUpdate(sql);
		      }
		    }  
		    catch (Exception e) {  
		      System.out.print("insert data error!");  
		      e.printStackTrace();  
		    }  
	}
	
	public void Show(){
			try {  
			      Connection connect = DriverManager.getConnection(  
			          "jdbc:mysql://localhost:3306/teacher","root","19960921");   
			      System.out.println("Success connect Mysql server!");  
			      Statement stmt = connect.createStatement();  
			      ResultSet rs = stmt.executeQuery("select * from teacher");  
			      System.out.println("����\t���\t�о�����\t��ϵ�绰\tEmail");                                                        
			      while (rs.next()) {
	                    System.out
	                            .println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getString(5));
	                }
			    }  
			    catch (Exception e) {  
			      System.out.print("get data error!");  
			      e.printStackTrace();  
			    }  
		}
	}


